import Frame21 from "./imports/Frame2608654/index";

export default function App() {
  return (
    <div style={{ minWidth: 2154, width: "100%", overflowX: "auto" }}>
      <div style={{ position: "relative", width: 2154, height: 5713 }}>
        <Frame21 />
      </div>
    </div>
  );
}
