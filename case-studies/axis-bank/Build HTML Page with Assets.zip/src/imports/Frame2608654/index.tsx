import svgPaths from "./svg-ce7ldh9k73";
import imgImage386 from "./2512ae1e5d4318a8536458d9bed27bc12a8e101f.png";
import imgLogo12 from "./96f460772bcbefd8ccade0ca7600ffe3a18a5c84.png";
import imgImage387 from "./b32319391a79af13365d1539918e3c42080fe6b3.png";

function Group() {
  return (
    <div className="absolute h-[61.05px] left-[318px] top-[262.11px] w-[249.001px]">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 249.001 61.0496">
        <g id="Group 32814">
          <path clipRule="evenodd" d={svgPaths.p25c3b200} fill="var(--fill-0, white)" fillRule="evenodd" id="Fill 10" />
          <path clipRule="evenodd" d={svgPaths.p25ddfb20} fill="var(--fill-0, white)" fillRule="evenodd" id="Fill 8" />
          <g id="Group 32815">
            <path clipRule="evenodd" d={svgPaths.p3df52a00} fill="var(--fill-0, white)" fillRule="evenodd" id="Fill 6" />
            <path clipRule="evenodd" d={svgPaths.p1a3f8600} fill="var(--fill-0, white)" fillRule="evenodd" id="Fill 4" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function MacBookPro() {
  return (
    <div className="absolute h-[912px] left-0 overflow-clip top-0 w-[2154px]" style={{ backgroundImage: "linear-gradient(93.6072deg, rgb(138, 3, 70) 14.286%, rgb(199, 0, 85) 72.217%, rgb(236, 0, 93) 168.45%)" }} data-name="MacBook Pro 14' - 85">
      <div className="absolute h-[245px] left-[-75px] top-[667px] w-[2558.5px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2558.5 245">
          <path d={svgPaths.p34d57100} id="Vector 9" opacity="0.5" stroke="url(#paint0_linear_1_134)" strokeWidth="2" />
          <defs>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_134" x1="-215.5" x2="2782.5" y1="122" y2="122">
              <stop stopColor="white" />
              <stop offset="1" stopColor="#FFDBDB" stopOpacity="0" />
              <stop offset="1" stopColor="white" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      <Group />
      <div className="-translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Fraunces:Regular',sans-serif] font-normal justify-center leading-[0] left-[318px] text-[92.252px] text-shadow-[2px_3px_0px_rgba(0,0,0,0.25)] text-white top-[574.5px] tracking-[-3.0681px] w-[1017px] whitespace-pre-wrap" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>
        <p className="font-['Fraunces:Italic',sans-serif] italic leading-[128.946px] mb-0" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>{`Enhancing `}</p>
        <p className="font-['Fraunces:Italic',sans-serif] italic leading-[128.946px] mb-0" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>{`Digital Accessibility of `}</p>
        <p className="font-['Fraunces:Bold',sans-serif] font-bold leading-[128.946px]" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>
          Axis Bank’s digital products
        </p>
      </div>
      <div className="absolute h-[245px] left-[-210px] top-[-41px] w-[1989px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1989 245">
          <path d={svgPaths.p121ae700} id="Vector 8" opacity="0.5" stroke="url(#paint0_linear_1_101)" strokeOpacity="0.63" />
          <defs>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_101" x1="39.2695" x2="2100.92" y1="237.36" y2="237.36">
              <stop stopColor="white" />
              <stop offset="1" stopColor="#FFDBDB" stopOpacity="0" />
              <stop offset="1" stopColor="white" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div className="absolute h-[1160px] left-[calc(58.33%+78.5px)] top-[109px] w-[595px]" data-name="image 386">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-full left-[-80.11%] max-w-none top-0 w-[259.81%]" src={imgImage386} />
        </div>
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="-translate-x-1/2 [word-break:break-word] absolute content-stretch flex flex-col gap-[28px] items-start leading-[0] left-1/2 top-[202px]">
      <div className="flex flex-col font-['Fraunces:SemiBold',sans-serif] font-semibold justify-center relative shrink-0 text-[#3a362a] text-[42px] tracking-[-1.3px] whitespace-nowrap" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>
        <p className="leading-[39.8px]">Overview</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal not-italic relative shrink-0 text-[#515151] text-[24px] w-[1296px]">
        <span className="leading-[1.5]">{`During my master's thesis in the Freecharge's `}</span>
        <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5]">DBAT (Digital Banking and Technology)</span>
        <span className="font-['Inter:Bold',sans-serif] font-bold leading-[1.5]">{` `}</span>
        <span className="leading-[1.5]">{`design team at Axis Design Labs, I had the unique opportunity to collaborate with Axis Bank. My primary focus was on enhancing digital accessibility for Axis Bank's products, specifically for disabled users. In addition to this significant project, I actively contributed to various other initiatives within the Axis Design Labs, making it a rewarding experience.`}</span>
      </p>
    </div>
  );
}

function Frame7() {
  return (
    <div className="[word-break:break-word] content-stretch flex flex-col gap-[28px] items-start leading-[0] relative shrink-0">
      <div className="flex flex-col font-['Fraunces:SemiBold',sans-serif] font-semibold justify-center relative shrink-0 text-[#3a362a] text-[42px] tracking-[-1.3px] whitespace-nowrap" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>
        <p className="leading-[39.8px]">About Axis Design Labs</p>
      </div>
      <div className="font-['Inter:Regular',sans-serif] font-normal not-italic relative shrink-0 text-[#515151] text-[24px] w-[945px]">
        <p className="leading-[1.5] mb-0">{`Axis Design Labs is the design team responsible for various aspects of Axis Bank's digital platforms. It comprises multiple pods, including Research, Communication, Motion Design, Interaction and Design System, each playing a pivotal role in improving and innovating the bank's digital offerings. Working here allowed me to be part of a dynamic and diverse design ecosystem.`}</p>
        <p className="leading-[1.5]">​</p>
      </div>
    </div>
  );
}

function Frame8() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex gap-[52px] items-center left-[calc(50%-0.5px)] top-[675px]">
      <div className="relative rounded-[300px] shrink-0 size-[284px]" data-name="Logo (1) 2">
        <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[300px]">
          <img alt="" className="absolute h-[153.85%] left-[-32.11%] max-w-none top-[-26.92%] w-[327.78%]" src={imgLogo12} />
        </div>
      </div>
      <Frame7 />
    </div>
  );
}

function Frame2() {
  return (
    <div className="[word-break:break-word] absolute content-stretch flex flex-col gap-[28px] items-start left-[calc(8.33%+177.5px)] text-white top-[1336px]">
      <div className="flex flex-col font-['Fraunces:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[42px] tracking-[-1.3px] whitespace-nowrap" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>
        <p className="leading-[39.8px]">Graduation Project</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.5] not-italic relative shrink-0 text-[24px] w-[842px]">{`The primary focus of my work in Axis Design Labs revolved around elevating the digital accessibility of Axis Bank's products for individuals with disabilities. This encompassed the development of a strategic roadmap, involving close collaboration with business units, the design team, and external stakeholders.`}</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[calc(8.33%+177.5px)] top-[1642px]">
      <div className="absolute h-[189px] left-[calc(8.33%+177.5px)] top-[1642px] w-[311px]">
        <div className="absolute inset-[-0.66%_-0.4%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 313.495 191.495">
            <g id="Ellipse 6333">
              <ellipse cx="156.748" cy="95.7476" fill="var(--fill-0, white)" fillOpacity="0.24" rx="155.5" ry="94.5" />
              <path d={svgPaths.p1fe6200} stroke="var(--stroke-0, white)" strokeOpacity="0.58" strokeWidth="1.24762" />
            </g>
          </svg>
        </div>
      </div>
      <div className="absolute h-[189px] left-[calc(16.67%+206px)] top-[1642px] w-[311px]">
        <div className="absolute inset-[-0.66%_-0.4%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 313.495 191.495">
            <g id="Ellipse 6334">
              <ellipse cx="156.748" cy="95.7476" fill="var(--fill-0, white)" fillOpacity="0.24" rx="155.5" ry="94.5" />
              <path d={svgPaths.p1fe6200} stroke="var(--stroke-0, white)" strokeOpacity="0.58" strokeWidth="1.24762" />
            </g>
          </svg>
        </div>
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] left-[calc(8.33%+286.5px)] lowercase not-italic opacity-90 text-[21.21px] text-center text-white top-[1736.5px] tracking-[-0.811px] whitespace-nowrap">
        <p className="leading-[30.442px]">Design System</p>
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] left-[calc(25%+237.5px)] lowercase not-italic opacity-90 text-[21.21px] text-center text-white top-[1736.5px] tracking-[-0.811px] whitespace-nowrap">
        <p className="leading-[30.442px]">Research team</p>
      </div>
      <div className="absolute flex h-[75px] items-center justify-center left-[calc(16.67%+257px)] top-[1771px] w-0">
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[75px]">
            <div className="absolute inset-[-5.33px_0_-5.33px_-7.11%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 80.3333 10.6667">
                <path d={svgPaths.p3ee75e00} fill="var(--stroke-0, white)" id="Line 6" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] left-[calc(16.67%+257.5px)] not-italic text-[16px] text-center text-white top-[1867.5px] tracking-[-1.3px] whitespace-nowrap">
        <p className="leading-[48.8px]">I work at the intersection of these 2 teams</p>
      </div>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[-66px] top-[1080px]">
      <div className="absolute h-[695px] left-[-66px] top-[1233px] w-[2285px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2285 695">
          <path d={svgPaths.p39504100} fill="url(#paint0_linear_1_132)" id="Rectangle 40784" />
          <defs>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_132" x1="-371.251" x2="3882.91" y1="411.327" y2="784.648">
              <stop stopColor="#95004A" />
              <stop offset="0.473381" stopColor="#C70055" />
              <stop offset="1" stopColor="#EC005D" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      <Frame2 />
      <div className="absolute h-[848px] left-[calc(50%+80px)] top-[1080px] w-[988px]" data-name="image 387">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[135.38%] left-0 max-w-none top-0 w-[99.82%]" src={imgImage387} />
        </div>
      </div>
      <Group2 />
    </div>
  );
}

function Frame3() {
  return (
    <div className="[word-break:break-word] absolute content-stretch flex gap-[88px] items-center leading-[0] left-[calc(16.67%+151px)] top-[2123px]">
      <div className="flex flex-col font-['Fraunces:SemiBold',sans-serif] font-semibold justify-center relative shrink-0 text-[#3a362a] text-[42px] tracking-[-1.3px] w-[326px]" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>
        <p className="leading-[52.3px]">My Roles and Responsibilities</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal not-italic relative shrink-0 text-[#515151] text-[24px] w-[827px]">
        <span className="leading-[1.5]">{`My role as a sole contributor encompassed a range of responsibilities, these included `}</span>
        <span className="font-['Inter:Bold',sans-serif] font-bold leading-[1.5]">conducting accessibility audits, conducting desk research, facilitating discussions with subject matter experts, generating innovative solutions, implementing strategies, and ensuring effective stakeholder cooperation.</span>
        <span className="leading-[1.5]">{` The combined efforts in these areas were instrumental in the successful development of our accessibility roadmap.`}</span>
      </p>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[calc(16.67%+151px)] top-[2123px]">
      <Frame3 />
    </div>
  );
}

function Frame9() {
  return (
    <div className="[word-break:break-word] absolute content-stretch flex flex-col gap-[28px] items-start left-[calc(16.67%+120px)] top-[2720px]">
      <div className="flex flex-col font-['Fraunces:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#3a362a] text-[42px] tracking-[-1.3px] whitespace-nowrap" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>
        <p className="leading-[39.8px]">Other projects that I have contributed in:</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal h-[72px] leading-[1.5] not-italic relative shrink-0 text-[#515151] text-[24px] w-[1080px]">Besides my primary project, I actively contributed to several other significant initiatives within Axis Design Labs, including:</p>
    </div>
  );
}

function Frame() {
  return (
    <div className="bg-[#faf6ef] content-stretch flex h-[48px] items-center justify-center opacity-90 px-[24px] py-[8px] relative rounded-[40px] shrink-0 w-[253px]">
      <div aria-hidden className="absolute border border-black border-solid inset-0 pointer-events-none rounded-[40px]" />
      <div className="[word-break:break-word] flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] lowercase not-italic relative shrink-0 text-[21px] text-black tracking-[-0.5px] whitespace-nowrap">
        <p className="leading-[normal]">In Design System team</p>
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <Frame />
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex flex-col items-start p-[10px] relative shrink-0">
      <Frame4 />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="[word-break:break-word] flex flex-col font-['Fraunces:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#af275f] text-[42px] tracking-[-1.3px] w-[561px]" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>
        <p className="leading-[59.8px]">Designing Slider Component for all Axis Bank Products</p>
      </div>
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex flex-col gap-[15px] items-start relative shrink-0">
      <Frame10 />
      <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[1.5] not-italic relative shrink-0 text-[#515151] text-[24px] w-[617px]">{`I took the lead in designing slider components to enhance the consistency and user experience of Axis Bank's digital products, contributing to a more seamless design system.`}</p>
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="[word-break:break-word] flex flex-col font-['Fraunces:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#af275f] text-[42px] tracking-[-1.3px] w-[619px]" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>
        <p className="leading-[59.8px]">Defining Patterns for the Subzero Design System</p>
      </div>
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex flex-col gap-[15px] items-start relative shrink-0">
      <Frame11 />
      <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[1.5] not-italic relative shrink-0 text-[#515151] text-[24px] w-[617px]">Within the design system pod, I’m working on creating design patterns for critical design elements such as logins, forms, OTPs, loaders, Assisted Flows and MPIN, which will further improved the cohesiveness of our digital offerings.</p>
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex gap-[41px] items-start relative shrink-0">
      <Frame13 />
      <div className="flex h-[315px] items-center justify-center relative shrink-0 w-0">
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[315px]">
            <div className="absolute inset-[-2px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 315 2">
                <line id="Line 46" opacity="0.4" stroke="var(--stroke-0, #C6A4AE)" strokeWidth="2" x2="315" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Frame14 />
    </div>
  );
}

function Frame17() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[34px] items-center left-1/2 px-[54px] py-[64px] rounded-[31px] top-[3083px]" style={{ backgroundImage: "linear-gradient(93.9949deg, rgba(149, 0, 74, 0.08) 14.286%, rgba(199, 0, 85, 0.08) 72.217%, rgba(236, 0, 93, 0.08) 168.45%)" }}>
      <Frame16 />
      <Frame15 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="bg-[#faf6ef] content-stretch flex h-[48px] items-center justify-center opacity-90 px-[24px] py-[8px] relative rounded-[40px] shrink-0 w-[253px]">
      <div aria-hidden className="absolute border border-black border-solid inset-0 pointer-events-none rounded-[40px]" />
      <div className="[word-break:break-word] flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] lowercase not-italic relative shrink-0 text-[21px] text-black tracking-[-0.5px] whitespace-nowrap">
        <p className="leading-[normal]">In Research team</p>
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <Frame1 />
    </div>
  );
}

function Frame18() {
  return (
    <div className="content-stretch flex flex-col items-start p-[10px] relative shrink-0">
      <Frame5 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="[word-break:break-word] flex flex-col font-['Fraunces:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#af275f] text-[42px] tracking-[-1.3px] w-[619px]" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>
        <p className="leading-[59.8px]">Conducted User Interviews for Axis AMC users</p>
      </div>
    </div>
  );
}

function Frame22() {
  return (
    <div className="content-stretch flex flex-col gap-[15px] items-start relative shrink-0">
      <Frame12 />
      <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[1.5] not-italic relative shrink-0 text-[#515151] text-[24px] w-[617px]">My involvement extended to conducting user interview research for Axis AMC (Asset Management Company) users along with Sr. Researchers. I played my part in designing research plans, conducting interviews, making notes and dissecting user feedback.</p>
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="[word-break:break-word] flex flex-col font-['Fraunces:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#af275f] text-[42px] tracking-[-1.3px] w-[619px]" style={{ fontVariationSettings: '"SOFT" 0, "WONK" 1' }}>
        <p className="leading-[59.8px]">Geurilla Testing for Fund Transfer Module</p>
      </div>
    </div>
  );
}

function Frame23() {
  return (
    <div className="content-stretch flex flex-col gap-[15px] items-start relative shrink-0">
      <Frame24 />
      <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[1.5] not-italic relative shrink-0 text-[#515151] text-[24px] w-[617px]">I collaborated in the guerrilla testing efforts for the fund transfer module. This involved planning the research, crafting relevant questions, designing tasks, and executing tasks physically, thereby contributing to the enhancement of this critical banking function.</p>
    </div>
  );
}

function Frame20() {
  return (
    <div className="content-stretch flex gap-[41px] items-start relative shrink-0">
      <Frame22 />
      <div className="flex h-[315px] items-center justify-center relative shrink-0 w-0">
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[315px]">
            <div className="absolute inset-[-2px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 315 2">
                <line id="Line 46" opacity="0.4" stroke="var(--stroke-0, #C6A4AE)" strokeWidth="2" x2="315" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Frame23 />
    </div>
  );
}

function Frame19() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[34px] items-center left-1/2 px-[54px] py-[64px] rounded-[31px] top-[3651px]" style={{ backgroundImage: "linear-gradient(93.7534deg, rgba(149, 0, 74, 0.08) 14.286%, rgba(199, 0, 85, 0.08) 72.217%, rgba(236, 0, 93, 0.08) 168.45%)" }}>
      <Frame18 />
      <Frame20 />
    </div>
  );
}

function MacBookPro1() {
  return (
    <div className="absolute bg-[#faf6ef] h-[4801px] left-0 overflow-clip top-[912px] w-[2154px]" data-name="MacBook Pro 14' - 86">
      <div className="-translate-x-1/2 absolute left-[calc(50%+0.22px)] size-[212.438px] top-[4359px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 212.438 212.438">
          <circle cx="106.219" cy="106.219" fill="url(#paint0_linear_1_109)" id="Ellipse 6339" opacity="0.1" r="106.219" />
          <defs>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_109" x1="157.163" x2="106.219" y1="17.6743" y2="212.438">
              <stop stopColor="#AF275F" />
              <stop offset="1" stopColor="#D9D9D9" stopOpacity="0.33" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div className="absolute h-[373px] left-[303px] top-[122px] w-[374px]">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 374 373">
          <ellipse cx="187" cy="186.5" fill="url(#paint0_linear_1_107)" id="Ellipse 6338" opacity="0.1" rx="187" ry="186.5" />
          <defs>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_107" x1="276.687" x2="187.448" y1="31.0326" y2="373.117">
              <stop stopColor="#AF275F" />
              <stop offset="1" stopColor="#D9D9D9" stopOpacity="0.33" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      <Frame6 />
      <Frame8 />
      <Group3 />
      <Group1 />
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-[1.5] left-[calc(50%-1px)] not-italic text-[#515151] text-[24px] text-center top-[4571px] w-[1196px]">{`Due to a non-disclosure agreement, I am unable to share specific details of my recent projects publicly. I would be happy to discuss my role and the outcomes of this work in a confidential setting`}</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[1.385] left-[calc(50%-47px)] not-italic text-[#636363] text-[93.444px] top-[4400px] whitespace-nowrap">🔒</p>
      <Frame9 />
      <div className="absolute flex items-center justify-center left-[324px] size-[482.267px] top-[2549px]">
        <div className="flex-none rotate-[-2.25deg]">
          <div className="relative size-[464.412px]">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 464.412 464.412">
              <circle cx="232.206" cy="232.206" fill="url(#paint0_linear_1_105)" id="Ellipse 40" opacity="0.1" r="232.206" />
              <defs>
                <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_105" x1="343.574" x2="232.206" y1="38.6379" y2="464.412">
                  <stop stopColor="#AF275F" />
                  <stop offset="1" stopColor="#D9D9D9" stopOpacity="0.33" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>
      </div>
      <Frame17 />
      <Frame19 />
    </div>
  );
}

export default function Frame21() {
  return (
    <div className="relative size-full">
      <MacBookPro />
      <MacBookPro1 />
    </div>
  );
}